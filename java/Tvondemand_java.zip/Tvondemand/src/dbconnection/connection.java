import java.sql.*;

public class connection {
// Specify the URL of the database. The format of the URL is [protocol]:[subprotocol]:[server:port/databaseName]
private static final String DB_URL = "jdbc:mariadb://localhost:3306/tvondemand";
public static void main(String[] args){
// try-with-resources
try (
// Step 1: Connect to database ("root" and "" are the default username and password for XAMPP)
Connection con = DriverManager.getConnection("jdbc:mariadb://localhost:3306/tvondemand", "root", "");
// Step 2: Initialize a Statement object for executing queries to database
Statement stmt = con.createStatement();
// Step 3: Execute query and get results
ResultSet resultSet = stmt.executeQuery("SELECT * FROM tvondemand");) {
// Step 4: Process and print results
ResultSetMetaData metaData = resultSet.getMetaData();
int numberOfColumns = metaData.getColumnCount();
// Print column names
for (int i = 1; i <= numberOfColumns; i++)
System.out.printf("%-8s\t", metaData.getColumnName(i));
System.out.println();
// Move cursor to the next row of the results and print the value of each column
while (resultSet.next()){
for (int i = 1; i <= numberOfColumns; i++)
System.out.printf("%-8s\t", resultSet.getObject(i));
System.out.println();
    }
} catch (SQLException ex) {
ex.printStackTrace();
}
}
}
